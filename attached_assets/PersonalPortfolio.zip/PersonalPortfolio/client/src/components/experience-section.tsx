import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { fadeInUp, slideInLeft, slideInRight, staggerContainer } from "@/lib/animations";

const experiences = [
  {
    period: "2022 - Present",
    title: "Senior Software Engineer",
    company: "TechCorp Solutions",
    description: "Leading full-stack development for enterprise applications. Architected microservices handling 100K+ daily users. Mentored 3 junior developers and implemented CI/CD pipelines.",
    technologies: ["React", "Node.js", "AWS"],
    side: "left",
  },
  {
    period: "2020 - 2022",
    title: "Software Engineer",
    company: "StartupXYZ",
    description: "Built responsive web applications from scratch. Collaborated with design team to implement pixel-perfect UIs. Optimized application performance by 40% through code refactoring and database optimization.",
    technologies: ["Vue.js", "Python", "MongoDB"],
    side: "right",
  },
  {
    period: "2019 - 2020",
    title: "Junior Developer",
    company: "WebDev Agency",
    description: "Developed and maintained client websites using modern frameworks. Gained experience in agile development methodologies and client communication. Contributed to 15+ successful project deliveries.",
    technologies: ["JavaScript", "PHP", "MySQL"],
    side: "left",
  },
];

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.h2
            variants={fadeInUp}
            className="text-4xl lg:text-5xl font-bold text-foreground mb-6"
          >
            Work Experience
          </motion.h2>
          <motion.p
            variants={fadeInUp}
            className="text-xl text-muted-foreground max-w-3xl mx-auto"
          >
            My professional journey through innovative companies and challenging projects.
          </motion.p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 bg-border h-full hidden lg:block" />

            {experiences.map((experience, index) => (
              <motion.div
                key={index}
                variants={staggerContainer}
                initial="initial"
                whileInView="animate"
                viewport={{ once: true }}
                className="relative flex items-center mb-12 last:mb-0"
              >
                {/* Desktop layout */}
                <div className="hidden lg:flex items-center w-full">
                  {experience.side === "left" ? (
                    <>
                      <motion.div
                        variants={slideInLeft}
                        className="w-1/2 pr-8 text-right"
                      >
                        <ExperienceCard experience={experience} align="right" />
                      </motion.div>
                      <TimelineDot />
                      <div className="w-1/2 pl-8" />
                    </>
                  ) : (
                    <>
                      <div className="w-1/2 pr-8" />
                      <TimelineDot />
                      <motion.div
                        variants={slideInRight}
                        className="w-1/2 pl-8"
                      >
                        <ExperienceCard experience={experience} align="left" />
                      </motion.div>
                    </>
                  )}
                </div>

                {/* Mobile layout */}
                <motion.div
                  variants={fadeInUp}
                  className="lg:hidden w-full"
                >
                  <ExperienceCard experience={experience} align="left" />
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TimelineDot() {
  return (
    <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-primary rounded-full border-4 border-card shadow-lg z-10" />
  );
}

interface ExperienceCardProps {
  experience: typeof experiences[0];
  align: "left" | "right";
}

function ExperienceCard({ experience, align }: ExperienceCardProps) {
  return (
    <Card className="bg-muted/50 hover:bg-muted/70 transition-colors duration-300">
      <CardContent className="p-6">
        <div className={`${align === "right" ? "text-right" : "text-left"}`}>
          <div className="text-primary font-semibold mb-2">{experience.period}</div>
          <h3 className="text-xl font-bold text-foreground mb-1">{experience.title}</h3>
          <div className="text-muted-foreground font-medium mb-3">{experience.company}</div>
          <p className="text-muted-foreground text-sm leading-relaxed mb-4">
            {experience.description}
          </p>
          <div className={`flex flex-wrap gap-2 ${align === "right" ? "justify-end" : "justify-start"}`}>
            {experience.technologies.map((tech) => (
              <Badge key={tech} variant="secondary" className="bg-primary/10 text-primary">
                {tech}
              </Badge>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
