import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { fadeInUp, slideInLeft, slideInRight, staggerContainer } from "@/lib/animations";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.h2
            variants={fadeInUp}
            className="text-4xl lg:text-5xl font-bold text-foreground mb-6"
          >
            About Me
          </motion.h2>
          <motion.p
            variants={fadeInUp}
            className="text-xl text-muted-foreground max-w-3xl mx-auto"
          >
            Driven by curiosity and powered by code, I transform complex problems into elegant solutions.
          </motion.p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            variants={slideInLeft}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            <img
              src="https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Modern tech environment workspace"
              className="rounded-2xl shadow-xl w-full"
            />
          </motion.div>

          <motion.div
            variants={slideInRight}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="space-y-6"
          >
            <motion.p
              variants={fadeInUp}
              className="text-lg text-muted-foreground leading-relaxed"
            >
              With over 5 years of experience in software development, I've had the privilege of working 
              with startups and established companies to build innovative AI-powered products. My journey began with 
              a Computer Science degree, but my real education happened through countless hours of coding, 
              debugging, and exploring the fascinating world of artificial intelligence.
            </motion.p>
            
            <motion.p
              variants={fadeInUp}
              className="text-lg text-muted-foreground leading-relaxed"
            >
              I specialize in full-stack development with a particular passion for integrating AI technologies 
              into web applications. From machine learning models to chatbots and data visualization, I love 
              creating intelligent solutions that make a real impact.
            </motion.p>

            <motion.div
              variants={staggerContainer}
              className="grid grid-cols-2 gap-6 pt-6"
            >
              <motion.div variants={fadeInUp}>
                <Card className="text-center p-6 bg-muted/50">
                  <CardContent className="pt-0">
                    <div className="text-3xl font-bold text-primary mb-2">50+</div>
                    <div className="text-muted-foreground">Projects Completed</div>
                  </CardContent>
                </Card>
              </motion.div>
              
              <motion.div variants={fadeInUp}>
                <Card className="text-center p-6 bg-muted/50">
                  <CardContent className="pt-0">
                    <div className="text-3xl font-bold text-primary mb-2">5+</div>
                    <div className="text-muted-foreground">Years Experience</div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
