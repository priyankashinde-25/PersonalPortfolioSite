import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { fadeInUp, staggerContainer, cardHover } from "@/lib/animations";
import { Code, Server, Settings, Brain } from "lucide-react";

const skillCategories = [
  {
    title: "Frontend Development",
    icon: Code,
    skills: [
      { name: "React/Next.js", level: 95 },
      { name: "TypeScript", level: 90 },
      { name: "Tailwind CSS", level: 85 },
    ],
  },
  {
    title: "Backend Development",
    icon: Server,
    skills: [
      { name: "Node.js/Express", level: 92 },
      { name: "Python/Django", level: 80 },
      { name: "PostgreSQL", level: 88 },
    ],
  },
  {
    title: "AI & Machine Learning",
    icon: Brain,
    skills: [
      { name: "TensorFlow/PyTorch", level: 75 },
      { name: "OpenAI APIs", level: 85 },
      { name: "Data Science", level: 70 },
    ],
  },
  {
    title: "Programming Languages",
    icon: Code,
    skills: [
      { name: "JavaScript/TypeScript", level: 95 },
      { name: "Python", level: 88 },
      { name: "Java", level: 75 },
    ],
  },
];

export default function SkillsSection() {
  return (
    <section id="skills" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.h2
            variants={fadeInUp}
            className="text-4xl lg:text-5xl font-bold text-foreground mb-6"
          >
            Skills & Technologies
          </motion.h2>
          <motion.p
            variants={fadeInUp}
            className="text-xl text-muted-foreground max-w-3xl mx-auto"
          >
            A comprehensive toolkit built through years of hands-on development and continuous learning.
          </motion.p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              variants={fadeInUp}
              whileHover={cardHover.whileHover}
            >
              <Card className="h-full bg-card shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-8">
                  <div className="text-primary text-4xl mb-4">
                    <category.icon className="h-10 w-10" />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-foreground mb-6">
                    {category.title}
                  </h3>
                  
                  <div className="space-y-4">
                    {category.skills.map((skill) => (
                      <div key={skill.name}>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-foreground">{skill.name}</span>
                          <span className="text-primary font-medium">{skill.level}%</span>
                        </div>
                        <div className="relative">
                          <Progress 
                            value={skill.level} 
                            className="h-2"
                          />
                          <div 
                            className="absolute top-0 left-0 h-2 skill-bar rounded-full transition-all duration-1000 ease-out"
                            style={{ width: `${skill.level}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
