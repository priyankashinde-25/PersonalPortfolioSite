import { motion } from "framer-motion";
import { Github, Linkedin, Twitter, Globe } from "lucide-react";
import { fadeInUp } from "@/lib/animations";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          variants={fadeInUp}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="text-3xl font-bold mb-4">
            <span className="text-primary">J</span>ohn Smith
          </div>
          
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Building the future with AI and code, one innovation at a time.
          </p>
          
          <div className="flex justify-center space-x-6 mb-8">
            {[
              { icon: Github, href: "#", label: "GitHub" },
              { icon: Linkedin, href: "#", label: "LinkedIn" },
              { icon: Twitter, href: "#", label: "Twitter" },
              { icon: Globe, href: "#", label: "Website" },
            ].map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                className="text-muted-foreground hover:text-primary transition-colors text-xl"
                aria-label={label}
              >
                <Icon className="h-6 w-6" />
              </a>
            ))}
          </div>
          
          <div className="border-t border-muted pt-6">
            <p className="text-muted-foreground text-sm">
              © 2024 John Smith. All rights reserved.
            </p>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
