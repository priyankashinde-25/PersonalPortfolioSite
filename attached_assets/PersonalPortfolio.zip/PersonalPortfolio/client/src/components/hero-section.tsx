import { motion } from "framer-motion";
import { Download, Mail, Github, Linkedin, Twitter, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fadeInUp, slideInLeft, slideInRight, float } from "@/lib/animations";

export default function HeroSection() {
  const handleDownloadResume = () => {
    // In a real implementation, this would trigger the actual download
    window.open("/api/resume", "_blank");
  };

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center pt-20">
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            variants={slideInLeft}
            initial="initial"
            animate="animate"
            className="space-y-8"
          >
            <motion.div
              variants={fadeInUp}
              className="text-primary font-medium text-lg"
            >
              Hello, I'm
            </motion.div>
            
            <motion.h1
              variants={fadeInUp}
              className="text-6xl lg:text-7xl font-bold text-foreground leading-tight"
            >
              John <span className="text-primary">Smith</span>
            </motion.h1>
            
            <motion.h2
              variants={fadeInUp}
              className="text-2xl lg:text-3xl text-muted-foreground font-light"
            >
              Full-Stack Software Engineer
            </motion.h2>
            
            <motion.p
              variants={fadeInUp}
              className="text-lg text-muted-foreground leading-relaxed max-w-xl"
            >
              Passionate about building scalable web applications and leveraging AI technologies to create innovative solutions. 
              Specializing in React, Node.js, and machine learning with 5+ years of experience.
            </motion.p>
            
            <motion.div
              variants={fadeInUp}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                onClick={handleDownloadResume}
                className="bg-primary hover:bg-primary/90 text-primary-foreground hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                size="lg"
              >
                <Download className="mr-2 h-4 w-4" />
                Download Resume
              </Button>
              
              <Button
                onClick={scrollToContact}
                variant="outline"
                size="lg"
                className="border-2 border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300"
              >
                <Mail className="mr-2 h-4 w-4" />
                Get In Touch
              </Button>
            </motion.div>
            
            <motion.div
              variants={fadeInUp}
              className="flex space-x-6"
            >
              {[
                { icon: Github, href: "#", label: "GitHub" },
                { icon: Linkedin, href: "#", label: "LinkedIn" },
                { icon: Twitter, href: "#", label: "Twitter" },
                { icon: Globe, href: "#", label: "Website" },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  className="text-muted-foreground hover:text-primary transition-colors duration-300 text-2xl"
                  aria-label={label}
                >
                  <Icon className="h-6 w-6" />
                </a>
              ))}
            </motion.div>
          </motion.div>
          
          <motion.div
            variants={slideInRight}
            initial="initial"
            animate="animate"
            className="relative"
          >
            <motion.div
              variants={float}
              animate="animate"
              className="relative z-10"
            >
              <img
                src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                alt="Professional developer workspace"
                className="rounded-2xl shadow-2xl w-full max-w-lg mx-auto"
              />
            </motion.div>
            
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-72 h-72 bg-primary/10 rounded-full blur-3xl -z-10" />
            <div className="absolute -bottom-8 -left-8 w-64 h-64 bg-accent/10 rounded-full blur-3xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
